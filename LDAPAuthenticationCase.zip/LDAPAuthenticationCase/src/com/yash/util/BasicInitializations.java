package com.yash.util;

public interface BasicInitializations {

	String LDAP_INITIAL_CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";//ldap vendor
	String LDAP_SECURITY_AUTHENTICATION = "simple";//security type simpple/ssl/sasl
	String LDAP_PROVIDER_URL = "ldap://inidradc01.yash.com/";//url
	String LDAP_SEARCH_BASE = "DC=yash,DC=com";//domain

}
